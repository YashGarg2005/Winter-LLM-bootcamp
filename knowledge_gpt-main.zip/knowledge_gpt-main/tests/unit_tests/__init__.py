"""All unit tests (lightweight tests)."""
